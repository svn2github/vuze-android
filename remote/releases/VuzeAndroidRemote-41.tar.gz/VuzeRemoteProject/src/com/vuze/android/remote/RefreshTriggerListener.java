package com.vuze.android.remote;

public interface RefreshTriggerListener
{
	public void triggerRefresh();
}
