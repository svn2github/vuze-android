package com.vuze.android.remote;

public interface RefreshTriggerListener
{
	void triggerRefresh();
}
