package com.vuze.android.remote.rpc;

import java.util.Map;

public interface SessionSettingsReceivedListener
{
	void sessionPropertiesUpdated(Map<?, ?> map);
}
