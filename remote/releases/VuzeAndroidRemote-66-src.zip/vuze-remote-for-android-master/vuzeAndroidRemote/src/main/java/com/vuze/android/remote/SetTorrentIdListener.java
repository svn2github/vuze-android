package com.vuze.android.remote;


public interface SetTorrentIdListener
{

	void setTorrentID(long id);

}