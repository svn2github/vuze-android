Android Switch Widget Backport
==============================

A backport of the Switch widget (http://developer.android.com/reference/android/widget/Switch.html)
that was introduced on Android 4.

This port works on Android 2.1+.

The current version of this library is `1.4.0`.

**IMPORTANT**
The **1.4.0** release has an incompatible change that requires you to update your `themes.xml` and layout files.
Specifically, `switchStyle` has been renamed to `asb_switchStyle`, and `switchPreferenceStyle` becomes `asb_switchPreferenceStyle`.
Similarly, all the switch attributes have been prefixed so `switchTextOn` is now `asb_switchTextOn`, and so on.

I am sorry about this but this has been necessary to avoid conflicts with the latest support library.

How to use
----------

### Adding the library to your project

#### Option 1: Gradle

The aar artifact is available at the **jcenter** repository. Declare the repository and the
dependency in your `build.gradle` file:
```groovy
repositories {
    jcenter()
}

 (...)

dependencies {
    compile 'org.jraf:android-switch-backport:1.4.0'
}
```

#### Option 2: Android library project (ant / Eclipse)

This is an Android library project, you have to add it as a dependency to your project (please
see [this page](http://developer.android.com/guide/developing/projects/projects-eclipse.html#ReferencingLibraryProject)
to know how to do that.)

#### Option 3: Maven

The apklib artifact is available at the **jcenter** repository. Declare the repository and the
dependency in your `pom.xml` file:
```xml
<repository>
    <id>central</id>
    <name>bintray</name>
    <url>http://jcenter.bintray.com</url>
</repository>

 (...)

<dependency>
    <groupId>org.jraf</groupId>
    <artifactId>android-switch-backport</artifactId>
    <version>1.4.0</version>
    <type>apklib</type>
</dependency>
```

Note: the artifacts used to be hosted on the JRAF.org repository, but due to server problems,
they are now hosted on jcenter. Please update your repository declarations!

### Using the Switch

Once you have done that, have a theme for your application (or Activity), that declares the `asb_switchStyle` item
to be one of the two possible themes: either `Widget.Holo.CompoundButton.Switch` (dark) or `Widget.Holo.Light.CompoundButton.Switch`
(light).

The simplest way to do that is to create a `themes.xml` file in your project's `res/values` folder with this contents:
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <style name="Theme" parent="@android:style/Theme">
        <item name="asb_switchStyle">@style/Widget.Holo.CompoundButton.Switch</item>
    </style>

</resources>
```
And use it in your Application or Activity by updating your `AndroidManifest.xml` file:
```xml
(...)
<application
    android:theme="@style/Theme"
(...)
```

or
```xml
(...)
<activity
    android:theme="@style/Theme"
(...)
```

Then in your layout xml files you use the widget like this:
```xml
<org.jraf.android.backport.switchwidget.Switch
    android:layout_width="wrap_content"
    android:layout_height="wrap_content" />
```

### Using the SwitchPreference

Add `asb_switchPreferenceStyle` to your 'themes.xml'

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <style name="Theme" parent="@android:style/Theme">
        <item name="asb_switchStyle">@style/Widget.Holo.CompoundButton.Switch</item>
        <item name="asb_switchPreferenceStyle">@style/Preference.SwitchPreference</item>
    </style>

</resources>
```

Then in your preference xml file:

```xml
<PreferenceScreen xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:switchpref="http://schemas.android.com/apk/res-auto" >

    <org.jraf.android.backport.switchwidget.SwitchPreference
        android:key="testKey"
        android:title="SwitchPreference Test"
        switchpref:asb_switchTextOff="@string/off"
        switchpref:asb_switchTextOn="@string/on"
        switchpref:asb_summaryOff="@string/summary_off"
        switchpref:asb_summaryOn="@string/summary_on" />

</PreferenceScreen>
```

### Sample app

A sample app is available in the [sample](sample) folder, and also on the Play Store:
[![Get it on Google Play](http://www.android.com/images/brand/get_it_on_play_logo_small.png)](https://play.google.com/store/apps/details?id=org.jraf.android.backport.switchwidget.sample)

Credits
-------

The code was copied directly from the Android 4.0.3 (API 15) source code, then slightly tweaked by myself (BoD@JRAF.org) to make
it run on 2.1+.  The few modifications I made are documented in the code (look for 'XXX' comments).
The SwitchPreference part was added later by Intrications (intrications.com / github.com/intrications), also by taking code
from Android and tweaking it a bit.  Other people also have contributed tweaks and fixes, please see this page for a detailed
list: https://github.com/BoD/android-switch-backport/graphs/contributors

Contributing
------------

Pull requests are welcome, as long as they are consistent to the original Switch / SwitchPreference of the
Android sdk.

Please do not contribute improvements that are not present in the original sdk classes!  I believe it would be
confusing for this backport to have a feature set different than the original sdk classes.  It would also lead to difficult situations if/when stopping using this backport and using the sdk classes instead (which should happen when dropping support for old platforms).  Thank you very much.

Licence
-------

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
