package com.vuze.android.remote.rpc;

import java.util.Map;

public interface SessionSettingsReceivedListener
{
	public void sessionPropertiesUpdated(Map<?, ?> map);
}
