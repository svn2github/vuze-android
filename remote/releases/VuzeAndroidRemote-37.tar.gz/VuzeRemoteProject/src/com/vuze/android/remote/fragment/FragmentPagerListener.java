package com.vuze.android.remote.fragment;

public interface FragmentPagerListener
{
	public void pageDeactivated();
	public void pageActivated();
}
