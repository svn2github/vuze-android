package com.vuze.android.remote;


public interface SetTorrentIdListener
{

	public void setTorrentID(long id);

}