/** Automatically generated file. DO NOT MODIFY */
package org.jraf.android.backport.switchwidget.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}